const DB_NAME = 'Student.db';
const TBL_NAME = 'student';
const NAME = 'Name';
const ENROLLMENT = 'Enrollment';
const AGE = 'Age';
const ID = 'Id';
