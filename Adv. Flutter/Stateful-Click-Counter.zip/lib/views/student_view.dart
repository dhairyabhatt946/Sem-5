import '../utils/import_export.dart';

class StudentView extends StatelessWidget {
  const StudentView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student List View Page'),
      ),
    );
  }
}
