import '../utils/import_export.dart';

class StudentController extends GetxController {
  StudentDb _studentDb = StudentDb();

  List<Map<String, dynamic>> _list = <Map<String, dynamic>>[].obs;

  List<Map<String, dynamic>> get list => _list;

  Future<List<Map<String, dynamic>>> getStudents() => _studentDb.getStudents();

  Future<void> addStudent(Map<String, dynamic> student) =>
      _studentDb.addStudent(student);

  Future<void> updateStudent(int index, Map<String, dynamic> student) =>
      _studentDb.updateStudent(index, student);

  Future<void> deleteStudent(int index) => _studentDb.deleteStudent(index);
}
