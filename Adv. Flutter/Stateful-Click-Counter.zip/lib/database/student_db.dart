import '../utils/import_export.dart';

class StudentDb {
  static final StudentDb _instance = StudentDb._internal();
  Database? _db;

  StudentDb._internal();

  factory StudentDb() {
    return _instance;
  }

  Future<void> get database async {
    _db ??= await _initDatabase();
  }

  Future<Database> _initDatabase() async {
    return await openDatabase(
      join(await getDatabasesPath(), DB_NAME),
      version: 1,
      onCreate: (db, version) {
        db.execute(
            'CREATE TABLE $TBL_NAME($ID INTEGER PRIMARY KEY AUTOINCREMENT, $ENROLLMENT TEXT UNIQUE NOT NULL, $NAME TEXT NOT NULL, $AGE INTEGER NOT NULL)');
      },
    );
  }

  Future<List<Map<String, dynamic>>> getStudents() async {
    database;
    return await _db!.rawQuery('SELECT * FROM $TBL_NAME');
  }

  Future<void> addStudent(Map<String, dynamic> student) async {
    database;
    await _db!.insert(TBL_NAME, student);
  }

  Future<void> updateStudent(int index, Map<String, dynamic> student) async {
    database;
    await _db!.update(TBL_NAME, student, where: '$ID = ?', whereArgs: [index]);
  }

  Future<void> deleteStudent(int index) async {
    database;
    await _db!.delete(TBL_NAME, where: '$ID = ?', whereArgs: [index]);
  }
}
